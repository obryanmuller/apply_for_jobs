# 📦 Secure Secret Sharing — Fullstack Serverless Application

Sistema fullstack para **compartilhamento seguro de senhas/segredos**, com geração criptográfica, expiração automática, limite de visualizações e destruição controlada.

O objetivo do projeto é permitir o envio seguro de credenciais através de um link temporário, evitando exposição em canais inseguros como e-mail, chat ou prints.

---

# 🏗️ Arquitetura Geral

## 🔹 Frontend

* **Next.js (App Router)**
* Geração criptográfica via **Web Crypto API**
* Interface dinâmica com validações preventivas
* Comunicação REST com API serverless

## 🔹 Backend

* **AWS Lambda (Python)**
* **API Gateway**
* **DynamoDB**
* TTL automático + destruição lógica
* Criptografia do segredo antes da persistência

---

# 🔐 Backend — Responsabilidades

## 📌 Criação de Segredos

Endpoint:
`POST /pwd`

### Entrada suportada

O backend aceita três cenários:

1️⃣ Senha enviada manualmente
2️⃣ Senha gerada no frontend
3️⃣ Campo vazio → backend gera senha

---

### Regras de validação

* `expiration_in_seconds > 0`
* `pass_view_limit > 0`
* senha enviada deve ser string válida
* geração aleatória valida políticas de caracteres

---

### Processamento interno

1. Geração de token seguro (`secrets.token_urlsafe`)
2. Hash SHA-256 do token
3. Criptografia do segredo
4. Persistência no DynamoDB com:

   * `token_hash`
   * `ciphertext`
   * `expires_at`
   * `max_views`
   * `views_used`
   * `revoked`

---

## 📌 Consumo do Segredo

Endpoint:
`GET /pwd/{pwdId}`

### Fluxo seguro

1. Token recebido na URL
2. Hash calculado no backend
3. Update condicional no DynamoDB:

   * só permite se:

     * não expirou
     * não atingiu limite
     * não revogado
4. Incremento atômico de visualizações
5. Se atingiu limite → **delete imediato**

---

### Resposta ao cliente

```json
{
  "pwdId": "...",
  "pwd": "segredo",
  "expiration_date": 1700000000,
  "view_count": 2
}
```

---

## 📌 Segurança implementada

* Token nunca armazenado em plaintext
* Apenas hash do token no banco
* Segredo criptografado antes da persistência
* Consumo com **update condicional atômico**
* Delete imediato após última visualização
* TTL como fallback de limpeza

---

# 🧪 Testes Automatizados (Última Alteração)

O backend possui testes com **pytest**, garantindo:

* validação de inputs
* fluxo de criação de segredo
* fluxo de consumo
* tratamento de erros
* arquitetura testável (sem side effects no import)
* isolamento da camada AWS via mocks

Execução:

```bash
python -m pytest -q
```

Cobertura:

```bash
python -m pytest --cov=. --cov-report=term-missing
```

---

# 🖥️ Frontend — Funcionalidades

## 1️⃣ Criação de Segredos

### 🔹 Entrada manual de senha

* Usuário pode digitar sua própria senha
* UI oculta opções de geração automaticamente
* evita parâmetros irrelevantes

---

### 🔹 Geração de senha no frontend

* Feita localmente via **crypto.getRandomValues**
* evita trafegar lógica de geração para o servidor
* usuário define:

  * letras
  * números
  * símbolos
  * comprimento

---

### 🔹 Validações e envio

* campo vazio permitido se critérios definidos
* backend assume geração nesses casos
* botão só habilita com input válido

---

## 2️⃣ Configuração de Expiração

### 🔹 Gestão de tempo

* usuário escolhe:

  * segundos
  * minutos
  * dias
* frontend converte para segundos antes do envio
* mínimo: **1 segundo**

---

### 🔹 Limite de acessos

* mínimo: **1 visualização**
* evita criação de dados já inválidos

---

## 3️⃣ Visualização e Segurança

### 🔹 Fluxo de visualização

* acesso pela URL ou pela Home
* backend valida token
* frontend exibe:

  * senha
  * expiração
  * visualizações restantes

---

### 🔹 Anti-Double Fetch (React Strict Mode)

Implementado via `useRef`.

Evita que requisições duplicadas:

* consumam o token acidentalmente
* invalidem links de uso único
* gerem erro antes da leitura

---

## 4️⃣ Gestão de Estado e UX

### 🔹 Ciclo de carregamento

Estados controlados:

* loading
* error
* data

`setLoading(false)` garantido sempre no `finally`.

Evita spinner infinito.

---

### 🔹 Sanitização de dados

* conversão explícita de inputs numéricos
* evita envio de strings
* garante compatibilidade com backend Python

---

## 5️⃣ Tratamento de Erros

Casos tratados:

* link inválido
* link expirado
* limite atingido

Resposta exibida em card de erro com opção de retorno seguro.

---

# 🚀 Objetivo do Projeto

Este sistema foi desenvolvido para demonstrar:

* arquitetura serverless real
* separação de responsabilidades
* segurança aplicada
* UX defensiva
* testes automatizados
* boas práticas de backend e frontend

---

# 📌 Possíveis Evoluções

* auditoria de acessos
* bloqueio por IP
* expiração por leitura parcial
* rate limiting
* criptografia com KMS
* observabilidade com CloudWatch + tracing
* testes de integração com Dynamo mockado

